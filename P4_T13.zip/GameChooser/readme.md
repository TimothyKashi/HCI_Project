12/11/19

Team 13
     Names: Timothy Kashi, Jake Lahr, Alexis Diaz
     Course: CS 420 Human Computer Interaction
     Assignment Project Part 4: Prototype Implementation


Instructions:
  1) drag 'index.html' into browser
